import { useEffect, useState } from "react";
import { API_BASE_URL } from "../api/config";
import NewsCard from "../components/NewsCard";

export default function Home() {
  const [news, setNews] = useState([]);

  useEffect(() => {
    fetch(`${API_BASE_URL}/news`)
      .then((res) => res.json())
      .then((data) => setNews(data));
  }, []);

  return (
    <main className="p-6 bg-gray-50 min-h-screen">
      <h2 className="text-3xl font-heading mb-6 text-red-700">Latest News</h2>
      <div className="grid md:grid-cols-3 gap-6">
        {news.map((n) => (
          <NewsCard key={n.NewsID} article={n} />
        ))}
      </div>
    </main>
  );
}
