import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { API_BASE_URL } from "../api/config";

export default function Article() {
  const { id } = useParams();
  const [article, setArticle] = useState(null);

  useEffect(() => {
    fetch(`${API_BASE_URL}/news/${id}`)
      .then((res) => res.json())
      .then((data) => setArticle(data));
  }, [id]);

  if (!article) return <p className="p-6">Loading...</p>;

  return (
    <main className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-heading mb-4">{article.Title}</h1>
      <img src={article.Image} className="w-full rounded-lg mb-4" alt={article.Title} />
      <p className="text-gray-700 font-body leading-relaxed">{article.Content}</p>
    </main>
  );
}
