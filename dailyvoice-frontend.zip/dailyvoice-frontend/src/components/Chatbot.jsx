import { useState } from "react";

export default function Chatbot() {
  const [visible, setVisible] = useState(false);
  const [messages, setMessages] = useState([]);

  const handleSend = (e) => {
    if (e.key === "Enter" && e.target.value.trim() !== "") {
      const newMsg = e.target.value.trim();
      setMessages([...messages, { user: true, text: newMsg }]);
      e.target.value = "";
      setTimeout(() => {
        setMessages((m) => [...m, { user: false, text: "Here's something you might find interesting." }]);
      }, 700);
    }
  };

  return (
    <>
      <button
        className="fixed bottom-5 right-5 bg-blue-600 text-white p-4 rounded-full shadow-lg"
        onClick={() => setVisible(!visible)}
      >
        💬
      </button>
      {visible && (
        <div className="fixed bottom-20 right-5 bg-white border w-80 h-96 rounded-xl shadow-lg flex flex-col">
          <div className="p-3 font-semibold bg-blue-600 text-white">Chat with DailyVoice</div>
          <div className="flex-1 overflow-y-auto p-3 space-y-2 text-sm">
            {messages.map((m, i) => (
              <p
                key={i}
                className={`p-2 rounded-lg ${
                  m.user ? "bg-blue-100 text-right" : "bg-gray-100 text-left"
                }`}
              >
                {m.text}
              </p>
            ))}
          </div>
          <input
            type="text"
            onKeyDown={handleSend}
            placeholder="Type your message..."
            className="border-t p-2 outline-none text-sm"
          />
        </div>
      )}
    </>
  );
}
