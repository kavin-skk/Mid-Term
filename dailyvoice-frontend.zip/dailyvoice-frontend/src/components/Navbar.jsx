import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <header className="flex justify-between items-center p-4 bg-white shadow-md sticky top-0 z-50">
      <h1 className="text-2xl font-heading text-red-600">
        <Link to="/">DailyVoice</Link>
      </h1>
      <nav className="space-x-4 font-body">
        <Link to="/category/politics">Politics</Link>
        <Link to="/category/sports">Sports</Link>
        <Link to="/category/tech">Tech</Link>
      </nav>
    </header>
  );
}
