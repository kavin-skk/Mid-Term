import { Link } from "react-router-dom";

export default function NewsCard({ article }) {
  return (
    <article className="bg-white rounded-xl shadow-lg overflow-hidden category-card">
      <img src={article.Image} alt={article.Title} className="w-full h-48 object-cover" />
      <div className="p-4">
        <h3 className="font-bold text-lg mb-2">
          <Link to={`/article/${article.NewsID}`} className="hover:text-red-700">
            {article.Title}
          </Link>
        </h3>
        <p className="text-sm text-gray-600">{article.Summary}</p>
      </div>
    </article>
  );
}
